# Ansible Collection - krai1.coll1

Documentation for the collection. Demo collection
